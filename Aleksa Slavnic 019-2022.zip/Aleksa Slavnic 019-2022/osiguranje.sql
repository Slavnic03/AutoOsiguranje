-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 19, 2024 at 01:54 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `osiguranje`
--

-- --------------------------------------------------------

--
-- Table structure for table `administracija`
--

DROP TABLE IF EXISTS `administracija`;
CREATE TABLE IF NOT EXISTS `administracija` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lozinka` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `administracija`
--

INSERT INTO `administracija` (`id`, `ime`, `prezime`, `username`, `lozinka`) VALUES
(1, 'Aleksa', 'Slavnic', 'aleksaslavnic12@gmail.com', '$2y$10$3ONTIWs64wm57Zt9dtw/PeI1IzLNrx0JlLephXgTb6WhsEK.3S2CS');

-- --------------------------------------------------------

--
-- Table structure for table `automobili`
--

DROP TABLE IF EXISTS `automobili`;
CREATE TABLE IF NOT EXISTS `automobili` (
  `id` int NOT NULL AUTO_INCREMENT,
  `administracija_id` int DEFAULT NULL,
  `marka` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `godina_proizvodnje` year DEFAULT NULL,
  `registarski_broj` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `broj_sasije` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datum_registracije` date DEFAULT NULL,
  `tip_vozila` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `korisnik_id` (`administracija_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `automobili`
--

INSERT INTO `automobili` (`id`, `administracija_id`, `marka`, `model`, `godina_proizvodnje`, `registarski_broj`, `broj_sasije`, `datum_registracije`, `tip_vozila`) VALUES
(1, NULL, 'Porche', 'GT3 RS', '2022', 'KG 0000 KG', 'JUAY7U8Y0NA98', '2024-05-17', 'Sportski');

-- --------------------------------------------------------

--
-- Table structure for table `premije`
--

DROP TABLE IF EXISTS `premije`;
CREATE TABLE IF NOT EXISTS `premije` (
  `id` int NOT NULL AUTO_INCREMENT,
  `korisnik_id` int DEFAULT NULL,
  `broj_polise` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datum_pocetka` date DEFAULT NULL,
  `datum_isteka` date DEFAULT NULL,
  `tip_osiguranja` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `premija` decimal(10,2) DEFAULT NULL,
  `status_polise` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `korisnik_id` (`korisnik_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `premije`
--

INSERT INTO `premije` (`id`, `korisnik_id`, `broj_polise`, `datum_pocetka`, `datum_isteka`, `tip_osiguranja`, `premija`, `status_polise`) VALUES
(1, NULL, '12345', '2024-05-20', '2024-05-31', 'Auto Osiguranje', 500.00, 'Aktivna');

-- --------------------------------------------------------

--
-- Table structure for table `steta`
--

DROP TABLE IF EXISTS `steta`;
CREATE TABLE IF NOT EXISTS `steta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vozilo_id` int DEFAULT NULL,
  `datum_incidenta` date DEFAULT NULL,
  `opis_incidenta` text COLLATE utf8mb4_unicode_ci,
  `lokacija_incidenta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `steta` decimal(10,2) DEFAULT NULL,
  `status_obrade` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vozilo_id` (`vozilo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `steta`
--

INSERT INTO `steta` (`id`, `vozilo_id`, `datum_incidenta`, `opis_incidenta`, `lokacija_incidenta`, `steta`, `status_obrade`) VALUES
(1, NULL, '2024-05-19', 'Nastao sudar zbog brze voznje', 'Tehnicka Skola Kragujevac', 1000.00, 'U obradi');

-- --------------------------------------------------------

--
-- Table structure for table `vozac`
--

DROP TABLE IF EXISTS `vozac`;
CREATE TABLE IF NOT EXISTS `vozac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jmbg` int NOT NULL,
  `kategorije` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datumrodjenja` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefon` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vozac`
--

INSERT INTO `vozac` (`id`, `ime`, `prezime`, `email`, `jmbg`, `kategorije`, `adresa`, `datumrodjenja`, `telefon`) VALUES
(1, 'Aleksa', 'Slavnic', 'aleksaslavnic12@gmail.com', 2147483647, 'A,B', 'Радоја Домановића 12, Крагујевац 34000', '2024-05-26', 123456789);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
