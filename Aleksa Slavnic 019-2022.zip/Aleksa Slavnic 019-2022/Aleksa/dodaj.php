<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">    <title>Dodavanje nove štete</title>
</head>
<body>
    <div class="container mt-5">
        <div class="card" id="karticaDodaj">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="vozac-tab" data-bs-toggle="tab" data-bs-target="#vozac" type="button" role="tab" aria-controls="vozac" aria-selected="true">Vozač</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link toggle" id="automobil-tab" data-bs-toggle="tab" data-bs-target="#automobil" type="button" role="tab" aria-controls="automobil" aria-selected="false">Automobil</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link toggle" id="steta-tab" data-bs-toggle="tab" data-bs-target="#steta" type="button" role="tab" aria-controls="steta" aria-selected="false">Šteta</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link toggle" id="premija-tab" data-bs-toggle="tab" data-bs-target="#premija" type="button" role="tab" aria-controls="premija" aria-selected="false">Premija</button>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="vozac" role="tabpanel" aria-labelledby="vozac-tab">
                        <form id="vozacForm" action="php/vozac.php" method="POST">
                            <div class="mb-3">
                                <label for="ime" class="form-label">Ime</label>
                                <input type="text" class="form-control" id="ime" name="ime" required>
                            </div>
                            <div class="mb-3">
                                <label for="prezime" class="form-label">Prezime</label>
                                <input type="text" class="form-control" id="prezime" name="prezime" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="jmbg" class="form-label">JMBG</label>
                                <input type="text" class="form-control" id="jmbg" name="jmbg" required>
                            </div>
                            <div class="mb-3">
                                <label for="kategorije" class="form-label">Kategorije</label>
                                <input type="text" class="form-control" id="kategorije" name="kategorije" required>
                            </div>
                            <div class="mb-3">
                                <label for="adresa" class="form-label">Adresa</label>
                                <input type="text" class="form-control" id="adresa" name="adresa" required>
                            </div>
                            <div class="mb-3">
                                <label for="datumrodjenja" class="form-label">Datum rođenja</label>
                                <input type="date" class="form-control" id="datumrodjenja" name="datumrodjenja" required>
                            </div>
                            <div class="mb-3">
                                <label for="telefon" class="form-label">Telefon</label>
                                <input type="text" class="form-control" id="telefon" name="telefon" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Sačuvaj</button>
                            
                        </form>
                    </div>
                    <div class="tab-pane fade" id="automobil" role="tabpanel" aria-labelledby="automobil-tab">
    <form id="automobilForm" action="php/automobili.php" method="POST">
        <div class="mb-3">
            <label for="marka" class="form-label">Marka</label>
            <input type="text" class="form-control" id="marka" name="marka" required>
        </div>
        <div class="mb-3">
            <label for="model" class="form-label">Model</label>
            <input type="text" class="form-control" id="model" name="model" required></div>
        <div class="mb-3">
            <label for="godina_proizvodnje" class="form-label">Godina proizvodnje</label>
            <input type="number" class="form-control" id="godina_proizvodnje" name="godina_proizvodnje" required>
        </div>
        <div class="mb-3">
            <label for="registarski_broj" class="form-label">Registarski broj</label>
            <input type="text" class="form-control" id="registarski_broj" name="registarski_broj" required>
        </div>
        <div class="mb-3">
            <label for="broj_sasije" class="form-label">Broj šasije</label>
            <input type="text" class="form-control" id="broj_sasije" name="broj_sasije" required>
        </div>
        <div class="mb-3">
            <label for="datum_registracije" class="form-label">Datum registracije</label>
            <input type="date" class="form-control" id="datum_registracije" name="datum_registracije" required>
        </div>
        <div class="mb-3">
            <label for="tip_vozila" class="form-label">Tip vozila</label>
            <input type="text" class="form-control" id="tip_vozila" name="tip_vozila" required>
        </div>
        <button type="submit" class="btn btn-primary">Sačuvaj</button>
    </form>
</div>
 <div class="tab-pane fade" id="steta" role="tabpanel" aria-labelledby="steta-tab">
    <form id="stetaForm" action="php/steta.php" method="POST">
        <div class="mb-3">
            <label for="datum_incidenta" class="form-label">Datum incidenta</label>
            <input type="date" class="form-control" id="datum_incidenta" name="datum_incidenta" required>
        </div>
        <div class="mb-3">
            <label for="opis_incidenta" class="form-label">Opis incidenta</label>
            <textarea class="form-control" id="opis_incidenta" name="opis_incidenta" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="lokacija_incidenta" class="form-label">Lokacija incidenta</label>
            <input type="text" class="form-control" id="lokacija_incidenta" name="lokacija_incidenta" required>
        </div>
        <div class="mb-3">
            <label for="steta" class="form-label">Šteta</label>
            <input type="number" class="form-control" id="steta" name="steta" required>
        </div>
        <div class="mb-3">
            <label for="status_obrade" class="form-label">Status obrade</label>
            <input type="text" class="form-control" id="status_obrade" name="status_obrade" required>
        </div>
        <button type="submit" class="btn btn-primary">Sačuvaj</button>
    </form>
</div>
<div class="tab-pane fade" id="premija" role="tabpanel" aria-labelledby="premija-tab">
    <form id="premijaForm" action="php/premija.php" method="POST">
        <div class="mb-3">
            <label for="broj_polise" class="form-label">Broj polise</label>
            <input type="text" class="form-control" id="broj_polise" name="broj_polise" required>
        </div>
        <div class="mb-3">
            <label for="datum_pocetka" class="form-label">Datum početka</label>
            <input type="date" class="form-control" id="datum_pocetka" name="datum_pocetka" required>
        </div>
        <div class="mb-3">
            <label for="datum_isteka" class="form-label">Datum isteka</label>
            <input type="date" class="form-control" id="datum_isteka" name="datum_isteka" required>
        </div>
        <div class="mb-3">
            <label for="tip_osiguranja" class="form-label">Tip osiguranja</label>
            <input type="text" class="form-control" id="tip_osiguranja" name="tip_osiguranja" required>
        </div>
        <div class="mb-3">
            <label for="premija" class="form-label">Premija</label>
            <input type="number" class="form-control" id="premija" name="premija" required>
        </div>
        <div class="mb-3">
            <label for="status_polise" class="form-label">Status polise</label>
            <input type="text" class="form-control" id="status_polise" name="status_polise" required>
        </div>
        <button type="submit" class="btn btn-primary">Sačuvaj</button>
    </form>
</div>          
<a href="data_page.php" class="btn btn-secondary mt-3">Nazad na pocetnu stranu</a>         
                </div>
            </div>
        </div>
    </div>
    
    <style>
        #karticaDodaj {
            margin: 0 auto; 
            margin-top: 0px;  
            max-width: 400px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
