<?php
// Uključivanje fajla za konekciju
include 'konekcija.php';

// Provera da li je forma poslana
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prikupljanje podataka iz forme
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $email = $_POST['email'];
    $jmbg = $_POST['jmbg'];
    $kategorije = $_POST['kategorije'];
    $adresa = $_POST['adresa'];
    $datumrodjenja = $_POST['datumrodjenja'];
    $telefon = $_POST['telefon'];

    // SQL upit za unos podataka u tabelu vozac
    $sql = "INSERT INTO vozac (ime, prezime, email, jmbg, kategorije, adresa, datumrodjenja, telefon)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Priprema SQL upita
    if ($stmt = $conn->prepare($sql)) {
        // Povezivanje parametara sa SQL upitom
        $stmt->bind_param("ssssssss", $ime, $prezime, $email, $jmbg, $kategorije, $adresa, $datumrodjenja, $telefon);

        // Izvršavanje SQL upita
        if ($stmt->execute()) {
            echo "Podaci su uspešno uneti.";
        } else {
            echo "Greška pri unosu podataka: " . $stmt->error;
        }

        // Zatvaranje statement-a
        $stmt->close();
    } else {
        echo "Greška pri pripremi SQL upita: " . $conn->error;
    }

    // Zatvaranje konekcije
    $conn->close();
}
?>
