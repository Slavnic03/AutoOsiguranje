<?php
// Uključivanje fajla za konekciju
include 'konekcija.php';

// Provera da li je forma poslana
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prikupljanje podataka iz forme
    $broj_polise = $_POST['broj_polise'];
    $datum_pocetka = $_POST['datum_pocetka'];
    $datum_isteka = $_POST['datum_isteka'];
    $tip_osiguranja = $_POST['tip_osiguranja'];
    $premija = $_POST['premija'];
    $status_polise = $_POST['status_polise'];

    // SQL upit za unos podataka u tabelu premija
    $sql = "INSERT INTO premije (broj_polise, datum_pocetka, datum_isteka, tip_osiguranja, premija, status_polise)
            VALUES (?, ?, ?, ?, ?, ?)";

    // Priprema SQL upita
    if ($stmt = $conn->prepare($sql)) {
        // Povezivanje parametara sa SQL upitom
        $stmt->bind_param("ssssis", $broj_polise, $datum_pocetka, $datum_isteka, $tip_osiguranja, $premija, $status_polise);

        // Izvršavanje SQL upita
        if ($stmt->execute()) {
            echo "Podaci su uspešno uneti.";
        } else {
            echo "Greška pri unosu podataka: " . $stmt->error;
        }

        // Zatvaranje statement-a
        $stmt->close();
    } else {
        echo "Greška pri pripremi SQL upita: " . $conn->error;
    }

    // Zatvaranje konekcije
    $conn->close();
}
?>
