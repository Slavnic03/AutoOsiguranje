<?php
// Uključivanje fajla za konekciju
include 'konekcija.php';

// Provera da li je forma poslana
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prikupljanje podataka iz forme
    $datum_incidenta = $_POST['datum_incidenta'];
    $opis_incidenta = $_POST['opis_incidenta'];
    $lokacija_incidenta = $_POST['lokacija_incidenta'];
    $steta = $_POST['steta'];
    $status_obrade = $_POST['status_obrade'];

    // SQL upit za unos podataka u tabelu steta
    $sql = "INSERT INTO steta (datum_incidenta, opis_incidenta, lokacija_incidenta, steta, status_obrade)
            VALUES (?, ?, ?, ?, ?)";

    // Priprema SQL upita
    if ($stmt = $conn->prepare($sql)) {
        // Povezivanje parametara sa SQL upitom
        $stmt->bind_param("sssis", $datum_incidenta, $opis_incidenta, $lokacija_incidenta, $steta, $status_obrade);

        // Izvršavanje SQL upita
        if ($stmt->execute()) {
            echo "Podaci su uspešno uneti.";
        } else {
            echo "Greška pri unosu podataka: " . $stmt->error;
        }

        // Zatvaranje statement-a
        $stmt->close();
    } else {
        echo "Greška pri pripremi SQL upita: " . $conn->error;
    }

    // Zatvaranje konekcije
    $conn->close();
}
?>
