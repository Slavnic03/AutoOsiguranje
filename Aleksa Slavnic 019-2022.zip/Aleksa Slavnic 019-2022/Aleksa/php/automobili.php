<?php
// Uključivanje fajla za konekciju
include 'konekcija.php';

// Provera da li je forma poslana
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prikupljanje podataka iz forme
    $marka = $_POST['marka'];
    $model = $_POST['model'];
    $godina_proizvodnje = $_POST['godina_proizvodnje'];
    $registarski_broj = $_POST['registarski_broj'];
    $broj_sasije = $_POST['broj_sasije'];
    $datum_registracije = $_POST['datum_registracije'];
    $tip_vozila = $_POST['tip_vozila'];

    // SQL upit za unos podataka u tabelu automobili
    $sql = "INSERT INTO automobili (marka, model, godina_proizvodnje, registarski_broj, broj_sasije, datum_registracije, tip_vozila)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Priprema SQL upita
    if ($stmt = $conn->prepare($sql)) {
        // Povezivanje parametara sa SQL upitom
        $stmt->bind_param("sssssss", $marka, $model, $godina_proizvodnje, $registarski_broj, $broj_sasije, $datum_registracije, $tip_vozila);

        // Izvršavanje SQL upita
        if ($stmt->execute()) {
            echo "Podaci su uspešno uneti.";
        } else {
            echo "Greška pri unosu podataka: " . $stmt->error;
        }

        // Zatvaranje statement-a
        $stmt->close();
    } else {
        echo "Greška pri pripremi SQL upita: " . $conn->error;
    }

    // Zatvaranje konekcije
    $conn->close();
}
?>
