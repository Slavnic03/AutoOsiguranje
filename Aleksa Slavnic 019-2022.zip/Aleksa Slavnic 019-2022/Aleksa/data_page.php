<?php
    // Uključivanje konekcije na bazu podataka
    include 'php/konekcija.php';

    // Pokretanje sesije
    session_start();

    // Provera da li je korisnik ulogovan
    if (!isset($_SESSION['korisnik_id'])) {     
        // Korisnik nije ulogovan, redirekcija na stranicu za login
        header("Location: index.php");
        exit();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Osiguranje</title>
</head>
<body>

<div class="container mt-5">
    <!-- Prva kartica - Vozaci -->
    <div class="card mb-3" id="tabela">
        <div class="card-header">
            <h5 class="card-title text-center">Vozaci</h5>
        </div>
        <div class="card-body">
            <div id="dugmici">
                <a href="dodaj.php" class="btn btn-primary mt-3">Dodaj</a>
                <a href="index.php" class="btn btn-primary mt-3">Odjava</a>
            </div>
            <?php
                // Iscitavanje podataka iz tabele vozac
                $upitVozac = "SELECT * FROM vozac";
                $rezultatVozac = mysqli_query($conn, $upitVozac);

                // Provera da li postoje podaci
                if ($rezultatVozac && mysqli_num_rows($rezultatVozac) > 0) {
                    // Postoje podaci, prikazi ih u tabeli
                    echo "<table class='table'>";
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>ID</th>";
                    echo "<th>Ime</th>";
                    echo "<th>Prezime</th>";
                    echo "<th>Email</th>";
                    echo "<th>JMBG</th>";
                    echo "<th>Kategorije</th>";
                    echo "<th>Adresa</th>";
                    echo "<th>Datum Rodjenja</th>";
                    echo "<th>Telefon</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    while ($red = mysqli_fetch_assoc($rezultatVozac)) {
                        echo "<tr>";
                        echo "<td>" . $red['id'] . "</td>";
                        echo "<td>" . $red['ime'] . "</td>";
                        echo "<td>" . $red['prezime'] . "</td>";
                        echo "<td>" . $red['email'] . "</td>";
                        echo "<td>" . $red['jmbg'] . "</td>";
                        echo "<td>" . $red['kategorije'] . "</td>";
                        echo "<td>" . $red['adresa'] . "</td>";
                        echo "<td>" . $red['datumrodjenja'] . "</td>";
                        echo "<td>" . $red['telefon'] . "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    // Nema podataka, prikazi poruku
                    echo "Nema podataka u tabeli vozac.";
                }
            ?>
        </div>
    </div>

    <!-- Druga kartica - Automobili -->
    <div class="card mb-3"  id="tabela">
        <div class="card-header">
            <h5 class="card-title text-center">Automobili</h5>
        </div>
        <div class="card-body">
            <?php
                // Iscitavanje podataka iz tabele automobil
                $upitAutomobili = "SELECT * FROM automobili";
                $rezultatAutomobili = mysqli_query($conn, $upitAutomobili);

                // Provera da li postoje podaci
                if ($rezultatAutomobili && mysqli_num_rows($rezultatAutomobili) > 0) {
                    // Postoje podaci, prikazi ih u tabeli
                    echo "<table class='table'>";
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>ID</th>";
                    echo "<th>Marka</th>";
                    echo "<th>Model</th>";
                    echo "<th>Godina Proizvodnje</th>";
                    echo "<th>Registarski Broj</th>";
                    echo "<th>Broj Šasije</th>";
                    echo "<th>Datum Registracije</th>";
                    echo "<th>Tip Vozila</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    while ($red = mysqli_fetch_assoc($rezultatAutomobili)) {
                        echo "<tr>";
                        echo "<td>" . $red['id'] . "</td>";
                        echo "<td>" . $red['marka'] . "</td>";
                        echo "<td>" . $red['model'] . "</td>";
                        echo "<td>" . $red['godina_proizvodnje'] . "</td>";
                        echo "<td>" . $red['registarski_broj'] . "</td>";
                        echo "<td>" . $red['broj_sasije'] . "</td>";
                        echo "<td>" . $red['datum_registracije'] . "</td>";
                        echo "<td>" . $red['tip_vozila'] . "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    // Nema podataka, prikazi poruku
                    echo "Nema podataka u tabeli automobil.";
                }
                ?>
            </div>
        </div>
    
        <!-- Treća kartica - Steta -->
        <div class="card mb-3"  id="tabela">
            <div class="card-header">
                <h5 class="card-title text-center">Steta</h5>
            </div>
            <div class="card-body">
                <?php
                    // Iscitavanje podataka iz tabele steta
                    $upitSteta = "SELECT * FROM steta";
                    $rezultatSteta = mysqli_query($conn, $upitSteta);
    
                    // Provera da li postoje podaci
                    if ($rezultatSteta && mysqli_num_rows($rezultatSteta) > 0) {
                        // Postoje podaci, prikazi ih u tabeli
                        echo "<table class='table'>";
                        echo "<thead>";
                        echo "<tr>";
                        echo "<th>ID</th>";
                        echo "<th>Datum Incidenta</th>";
                        echo "<th>Lokacija Incidenta</th>";
                        echo "<th>Steta</th>";
                        echo "<th>Status Obrade</th>";
                        echo "</tr>";
                        echo "</thead>";
                        echo "<tbody>";
                        while ($red = mysqli_fetch_assoc($rezultatSteta)) {
                            echo "<tr>";
                            echo "<td>" . $red['id'] . "</td>";
                            echo "<td>" . $red['datum_incidenta'] . "</td>";
                            echo "<td>" . $red['lokacija_incidenta'] . "</td>";
                            echo "<td>" . $red['steta'] . "</td>";
                            echo "<td>" . $red['status_obrade'] . "</td>";
                            echo "</tr>";
                        }
                        echo "</tbody>";
                        echo "</table>";
                    } else {
                        // Nema podataka, prikazi poruku
                        echo "Nema podataka u tabeli steta.";
                    }
                ?>
            </div>
        </div>
    
        <!-- Četvrta kartica - Premije -->
        <div class="card mb-3"  id="tabela">
            <div class="card-header">
                <h5 class="card-title text-center">Premije</h5>
            </div>
            <div class="card-body">
                <?php
                    // Iscitavanje podataka iz tabele premije
                    $upitPremije = "SELECT * FROM premije";
                    $rezultatPremije = mysqli_query($conn, $upitPremije);
    
                    // Provera da li postoje podaci
                    if ($rezultatPremije && mysqli_num_rows($rezultatPremije) > 0) {
                        // Postoje podaci, prikazi ih u tabeli
                        echo "<table class='table'>";
                        echo "<thead>";
                        echo "<tr>";
                        echo "<th>ID</th>";
                        echo "<th>Broj Polise</th>";
                        echo "<th>Datum Početka</th>";
                        echo "<th>Datum Istečka</th>";
                        echo "<th>Tip Osiguranja</th>";
                        echo "<th>Premija</th>";
                        echo "<th>Status Polise</th>";
                        echo "</tr>";
                        echo "</thead>";
                        echo "<tbody>";
                        while ($red = mysqli_fetch_assoc($rezultatPremije)) {
                            echo "<tr>";
                            echo "<td>" . $red['id'] . "</td>";
                            echo "<td>" . $red['broj_polise'] . "</td>";
                            echo "<td>" . $red['datum_pocetka'] . "</td>";
                            echo "<td>" . $red['datum_isteka'] . "</td>";
                            echo "<td>" . $red['tip_osiguranja'] . "</td>";
                            echo "<td>" . $red['premija'] . "</td>";
                            echo "<td>" . $red['status_polise'] . "</td>";
                            echo "</tr>";
                        }
                        echo "</tbody>";
                        echo "</table>";
                    } else {
                        // Nema podataka, prikazi poruku
                        echo "Nema podataka u tabeli premije.";
                    }
                ?>
            </div>
        </div>
    </div>
    
    <style>
        #tabela{
            margin: 0 auto;   
            margin-top: 60px;  
             max-width: 1200px;   
            }


            #dugmici{
                display: flex;
                padding-right: 20px;
                margin-left: 500px;
            
                }
    </style>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    </body>
    </html>